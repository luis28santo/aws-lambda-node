"use strict";
var __getOwnPropNames = Object.getOwnPropertyNames;
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};

// swagger/swagger.js
var require_swagger = __commonJS({
  "swagger/swagger.js"(exports2, module2) {
    module2.exports = {
      "swagger": "2.0",
      "info": {
        "title": "AWS-SERVERLESS-NODE",
        "version": "1",
        "description": "Lambdas de aws para pasar la prueba"
      },
      "paths": {
        "/": {
          "get": {
            "summary": "api",
            "description": "Api base",
            "operationId": "api.get./",
            "consumes": [
              "application/json"
            ],
            "produces": [
              "application/json"
            ],
            "parameters": [],
            "responses": {
              "200": {
                "description": "this went well"
              }
            }
          }
        },
        "/character": {
          "post": {
            "summary": "createCharacter",
            "description": "",
            "tags": [
              "characterDynamoDB"
            ],
            "operationId": "createCharacter.post./character",
            "consumes": [
              "application/json"
            ],
            "produces": [
              "application/json"
            ],
            "parameters": [
              {
                "in": "body",
                "name": "body",
                "description": "Body required in the request",
                "required": true,
                "schema": {
                  "$ref": "#/definitions/CharacterRequest"
                }
              }
            ],
            "responses": {
              "200": {
                "description": "Se creo correctamente el personaje en BD.",
                "schema": {
                  "$ref": "#/definitions/CharacterResp"
                }
              },
              "400": {
                "description": "El body es nulo."
              }
            }
          },
          "get": {
            "summary": "getCharacters",
            "description": "",
            "tags": [
              "characterDynamoDB"
            ],
            "operationId": "getCharacters.get./character",
            "consumes": [
              "application/json"
            ],
            "produces": [
              "application/json"
            ],
            "parameters": [],
            "responses": {
              "200": {
                "description": "Se obtienen correctamente todos los personajes de BD.",
                "schema": {
                  "$ref": "#/definitions/CharacterResp"
                }
              }
            }
          }
        },
        "/sw/character": {
          "get": {
            "summary": "getSWCharacters",
            "description": "",
            "tags": [
              "swapi"
            ],
            "operationId": "getSWCharacters.get./sw/character",
            "consumes": [
              "application/json"
            ],
            "produces": [
              "application/json"
            ],
            "parameters": [
              {
                "in": "query",
                "name": "name",
                "type": "string",
                "description": "Se puede probar con el nombre de 'Sky'",
                "required": false
              }
            ],
            "responses": {
              "200": {
                "description": "Nos traemos todos los personajes de la api 'https://swapi.py4e.com/api/people/' o 'https://swapi.py4e.com/api/people/?search=XXXXXXXX'.",
                "schema": {
                  "$ref": "#/definitions/CharacterFullEsp"
                }
              }
            }
          }
        }
      },
      "definitions": {
        "CharacterRequest": {
          "properties": {
            "anio_nacimiento": {
              "title": "CharacterRequest.anio_nacimiento",
              "type": "string"
            },
            "color_ojos": {
              "title": "CharacterRequest.color_ojos",
              "type": "string"
            },
            "genero": {
              "title": "CharacterRequest.genero",
              "type": "string"
            },
            "color_pelo": {
              "title": "CharacterRequest.color_pelo",
              "type": "string"
            },
            "altura": {
              "title": "CharacterRequest.altura",
              "type": "string"
            },
            "mundo_natal": {
              "title": "CharacterRequest.mundo_natal",
              "type": "string"
            },
            "masa": {
              "title": "CharacterRequest.masa",
              "type": "string"
            },
            "nombre": {
              "title": "CharacterRequest.nombre",
              "type": "string"
            },
            "color_piel": {
              "title": "CharacterRequest.color_piel",
              "type": "string"
            }
          },
          "required": [
            "anio_nacimiento",
            "color_ojos",
            "genero",
            "color_pelo",
            "altura",
            "mundo_natal",
            "masa",
            "nombre",
            "color_piel"
          ],
          "additionalProperties": false,
          "title": "CharacterRequest",
          "type": "object"
        },
        "CharacterResp": {
          "properties": {
            "anio_nacimiento": {
              "title": "CharacterResp.anio_nacimiento",
              "type": "string"
            },
            "color_ojos": {
              "title": "CharacterResp.color_ojos",
              "type": "string"
            },
            "genero": {
              "title": "CharacterResp.genero",
              "type": "string"
            },
            "color_pelo": {
              "title": "CharacterResp.color_pelo",
              "type": "string"
            },
            "altura": {
              "title": "CharacterResp.altura",
              "type": "string"
            },
            "mundo_natal": {
              "title": "CharacterResp.mundo_natal",
              "type": "string"
            },
            "masa": {
              "title": "CharacterResp.masa",
              "type": "string"
            },
            "nombre": {
              "title": "CharacterResp.nombre",
              "type": "string"
            },
            "color_piel": {
              "title": "CharacterResp.color_piel",
              "type": "string"
            },
            "id": {
              "title": "CharacterResp.id",
              "type": "string"
            }
          },
          "required": [
            "anio_nacimiento",
            "color_ojos",
            "genero",
            "color_pelo",
            "altura",
            "mundo_natal",
            "masa",
            "nombre",
            "color_piel",
            "id"
          ],
          "additionalProperties": false,
          "title": "CharacterResp",
          "type": "object"
        },
        "CharacterFullEsp": {
          "properties": {
            "peliculas": {
              "title": "CharacterFullEsp.peliculas",
              "type": "string"
            },
            "especies": {
              "title": "CharacterFullEsp.especies",
              "type": "string"
            },
            "vehiculos": {
              "title": "CharacterFullEsp.vehiculos",
              "type": "string"
            },
            "naves_estelares": {
              "title": "CharacterFullEsp.naves_estelares",
              "type": "string"
            },
            "creado": {
              "title": "CharacterFullEsp.creado",
              "type": "string"
            },
            "editado": {
              "title": "CharacterFullEsp.editado",
              "type": "string"
            },
            "url": {
              "title": "CharacterFullEsp.url",
              "type": "string"
            },
            "anio_nacimiento": {
              "title": "CharacterFullEsp.anio_nacimiento",
              "type": "string"
            },
            "color_ojos": {
              "title": "CharacterFullEsp.color_ojos",
              "type": "string"
            },
            "genero": {
              "title": "CharacterFullEsp.genero",
              "type": "string"
            },
            "color_pelo": {
              "title": "CharacterFullEsp.color_pelo",
              "type": "string"
            },
            "altura": {
              "title": "CharacterFullEsp.altura",
              "type": "string"
            },
            "mundo_natal": {
              "title": "CharacterFullEsp.mundo_natal",
              "type": "string"
            },
            "masa": {
              "title": "CharacterFullEsp.masa",
              "type": "string"
            },
            "nombre": {
              "title": "CharacterFullEsp.nombre",
              "type": "string"
            },
            "color_piel": {
              "title": "CharacterFullEsp.color_piel",
              "type": "string"
            }
          },
          "required": [
            "peliculas",
            "especies",
            "vehiculos",
            "naves_estelares",
            "creado",
            "editado",
            "url",
            "anio_nacimiento",
            "color_ojos",
            "genero",
            "color_pelo",
            "altura",
            "mundo_natal",
            "masa",
            "nombre",
            "color_piel"
          ],
          "additionalProperties": false,
          "title": "CharacterFullEsp",
          "type": "object"
        }
      },
      "securityDefinitions": {}
    };
  }
});

// swagger/swagger-json.js
var swagger = require_swagger();
exports.handler = async () => {
  return {
    statusCode: 200,
    body: JSON.stringify(swagger)
  };
};
