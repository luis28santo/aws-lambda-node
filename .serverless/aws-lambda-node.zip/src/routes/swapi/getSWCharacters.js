var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/routes/swapi/getSWCharacters.ts
var getSWCharacters_exports = {};
__export(getSWCharacters_exports, {
  getSWCharacters: () => getSWCharacters
});
module.exports = __toCommonJS(getSWCharacters_exports);

// src/services/swService.ts
var SWService = class {
  static async getCharacters() {
    const { results } = await fetch("https://swapi.py4e.com/api/people/", { method: "GET" }).then((e) => e.json());
    return results;
  }
};

// src/utils/keys_character_esp.ts
var KEYS_CHARACTER_ESP = {
  birth_year: "anio_nacimiento",
  eye_color: "color_ojos",
  gender: "genero",
  hair_color: "color_pelo",
  height: "altura",
  homeworld: "mundo_natal",
  mass: "masa",
  name: "nombre",
  skin_color: "color_piel",
  films: "peliculas",
  species: "especies",
  vehicles: "vehiculos",
  starships: "naves_estelares",
  created: "creado",
  edited: "editado",
  url: "url"
};

// src/mappers/SWCharacterMapper.ts
var SWCharacterMapper = class {
  static changeKeysEnToKeysEsp(characters) {
    const charactersEsp = characters.map((character) => {
      return this.changeKeysEnToEsp(character);
    });
    return charactersEsp;
  }
  static changeKeysEnToEsp(character) {
    const newCharacter = {};
    for (const key in character) {
      if (Object.prototype.hasOwnProperty.call(character, key)) {
        const newKey = KEYS_CHARACTER_ESP[key] ?? key;
        newCharacter[newKey] = character[key];
      }
    }
    return newCharacter;
  }
};

// src/routes/swapi/getSWCharacters.ts
var getSWCharacters = async (event) => {
  const characters = await SWService.getCharacters();
  const charactersEsp = SWCharacterMapper.changeKeysEnToKeysEsp(characters);
  return {
    statusCode: 200,
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(charactersEsp)
  };
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  getSWCharacters
});
